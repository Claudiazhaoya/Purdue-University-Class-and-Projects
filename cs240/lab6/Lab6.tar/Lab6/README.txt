This directory contains four C programs, each experimenting with a cipher function to be implemented for Lab 6 of CS240, Spring, 2013. The lab handout posted on Piazza describes the details of this lab assignment.  

- Z. Li
