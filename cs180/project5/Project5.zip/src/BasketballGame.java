public class BasketballGame {
	private String team1;
	private String team2;
	private int team1Score = 0;
	private int team2Score = 0;
	private boolean status;
 
	private int[] number = {0 , 0 , 0};
 
	public BasketballGame(String team1, String team2, int team1Score, int team2Score, boolean status) {
	 	setTeam1(team1);
	 	setTeam2(team2);
	 	setTeam1Score(team1Score);
	 	setTeam2Score(team2Score);
	 	setStatus(status);
	}
 
	public void setTeam1(String name) { this.team1 = name; }
	public void setTeam2(String name) { this.team2 = name; }
 
	public void setTeam1Score(int score) {
		if (score == 1 || score == 2 || score == 3) {
			this.team1Score += score;
			number[score - 1]++;
		} else {
			this.team1Score += 0;
		}
	}
	public void setTeam2Score(int score) {
		if ( score == 1 || score == 2 || score == 3) {
			this.team2Score += score;
			number[score - 1] ++;
		} else {
			this.team2Score += 0;
		}
	}
	public void setStatus(boolean status) { this.status = status; }
 
	public int getTeam1Score() { return team1Score; }
	public int getTeam2Score() { return team2Score; }
	public String getTeam1() { return team1; }
	public String getTeam2() { return team2; }
	public int getNumBasket(int input) { return number[input]; }
	public String getCurrentWinner() {
		if (team1Score > team2Score) {
			return team1;
		} else {
			return team2;
		}
	}
 
 
 
 
}
 