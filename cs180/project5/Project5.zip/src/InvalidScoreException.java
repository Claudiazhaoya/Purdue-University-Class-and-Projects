
public class InvalidScoreException extends Exception {
	String s = " Is Not a valid Score Please try again";
	String e = "";
	public InvalidScoreException(int e) {
		this.e = e + s;
	}
	public String toString() {
		return e;
	}
}
