package heap;

import java.util.*;
import global.*;
import diskmgr.*;
import java.io.*;
import chainexception.ChainException;

public class HeapFile{
	private String name;
	private int recordCount;
	PageId firstPid;
	HFPage hfpage;
	//private AVLTree fullPages = new AVLTree();
	//private AVLTree freePages = new AVLTree();
	private TreeMap<Integer, String> fullPages = new TreeMap<>();
	
	public HeapFile(String name){
		
		recordCount=0;
		hfpage = new HFPage();
		if(name != null && !(name.equals(""))){
			this.name = name;
			firstPid = Minibase.DiskManager.get_file_entry(name);
			if(firstPid == null){	
				//System.out.println("new File");
				firstPid = Minibase.BufferManager.newPage(hfpage, 1);
				Minibase.DiskManager.add_file_entry(name, firstPid);
				//init
				Minibase.BufferManager.unpinPage(firstPid, true);
			}else{
				//System.out.println("old File");
				Minibase.BufferManager.pinPage(firstPid, hfpage, false);
				Minibase.BufferManager.unpinPage(firstPid, true);
				//start counting records
				/*HFPage tempPage = hfpage;
				HopenScan.
				while(tempPage != null){
					RID tempRid = tempPage.firstRecord();
					while(tempRid != null){
						recordCount++;
						tempRid = hfpage.nextRecord(tempRid);
					}
					tempPage = tempPage.getNextPage();
				}*/
				/*HeapScan scanner = this.openScan();
				while(scanner.hasNext()){
					recordCount++;
				}
				scanner.close();*/
			}
		}else{
			name = "temp";
			firstPid = Minibase.BufferManager.newPage(hfpage, 1);
			Minibase.DiskManager.add_file_entry(name, firstPid);
			//init
			Minibase.BufferManager.unpinPage(firstPid, true);
		}
	}
	
	
	
	
	public RID insertRecord(byte[] record)throws ChainException{
		if(record.length > 1004){
			//throw new SpaceNotAvailableException(null, "record too big");
		}
		RID rid = new RID();
		PageId hfpid = this.firstPid;
		

Minibase.BufferManager.pinPage(hfpid, hfpage, false);
if(hfpage.getFreeSpace() >= record.length){
rid = hfpage.insertRecord(record);
recordCount++;
Minibase.BufferManager.unpinPage(hfpid, true);
return rid;
}else{return null;}
/*
		//loop through hfpg to find free space and insert the record
		//System.out.println("DASFKJDLF");
		while(hfpid.pid != -1){
		//System.out.println("HEERERERES");
			Minibase.BufferManager.pinPage(hfpid, hfpage, false);
			if(hfpage.getFreeSpace() >= record.length){
				rid = hfpage.insertRecord(record);
				recordCount++;
				if(hfpage.getFreeSpace() == 0){// the page doesnt have anymore space
					//fullpages.put(hfpg.pid, hf.name);
				}
				i++;
				Minibase.BufferManager.unpinPage(hfpid, true);
				return rid;
			}
			Minibase.BufferManager.unpinPage(hfpid, true);
			hfpid = hfpage.getNextPage();
		}
*/
		//create a new page and insert record into new page
		/*hfpg = new HFPage();
		hfpid = Minibase.BufferManager.newPage(hfpg, 1);
		//init
		Minibase.BufferManager.unpinPage(hfpid, true);
		Minibase.BufferManager.pinPage(hfpid, hfpg, false);
		rid = hfpg.insertRecord(record);
		Minibase.BufferManager.unpinPage(hfpid, true);

		//check if the newly created page is full after insert
		if(hfpage.getFreeSpace() == 0){
			//fullpages.insert(hfpg.pid)
					try{
			throw new ChainException(null,"FUCK YOU");
		}catch (ChainException e){
			throw new ChainException(e,"Chain exception in close*)");
			}
		}else{
			hfpid = hfpage.getCurPage();
		}*/
		
		
		//recordCount++;
		//return rid;
	}
	public Tuple getRecord(RID rid){
		
		/*PageId pid = rid.firstPid;
		HFPage hfpage = new HFPage();
		pinPage(new PageId(id.pid), hfpage, false);
		Tuple tup = hfpage.getRecord();*/
		byte[] b = new byte[100];
		Tuple tup = new Tuple(b,0,1);
		return tup;
	}
	public boolean updateRecord(RID rid, Tuple newRecord)throws ChainException {
				try{
			throw new ChainException(null,"FUCK YOU");
		}catch (ChainException e){
			throw new ChainException(e,"Chain exception in close");
			}
		//return true;
	}
	public boolean deleteRecord(RID rid){
		recordCount--;
		return true;
	}
	public int getRecCnt(){ //get number of records in the file
		return recordCount;
	}
	public HeapScan openScan(){
		HeapScan heapscanner = new HeapScan(this);
		return heapscanner;
	}
}
