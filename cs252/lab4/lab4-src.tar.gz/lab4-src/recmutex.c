#include <stdio.h>
#include <pthread.h>
#include <errno.h>
#include "recmutex.h"

int recursive_mutex_init (recursive_mutex_t *mu)
{
}

int recursive_mutex_destroy (recursive_mutex_t *mu)
{
}

int recursive_mutex_lock (recursive_mutex_t *mu)
{
}

int recursive_mutex_unlock (recursive_mutex_t *mu)
{
}
