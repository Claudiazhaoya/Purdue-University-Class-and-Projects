int getCharType(char);
char lowerCaseOf(char);
int strLen(char*);
int strNCmp(char*, char*, int);
void replaceChar(char*, char, int);
