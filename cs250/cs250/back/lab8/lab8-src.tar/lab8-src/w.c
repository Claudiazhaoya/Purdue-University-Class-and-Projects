
long i;

void main()
{
	i = 4;
	while(i) {
		printf("i=%d\n",i);
		i = i - 1;
	}	
}
