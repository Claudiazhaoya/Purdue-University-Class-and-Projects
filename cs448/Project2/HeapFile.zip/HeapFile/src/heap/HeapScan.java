package heap;

import bufmgr.*;
import global.*;
import chainexception.ChainException;

public class HeapScan implements GlobalConst{
	HeapFile hf;
	HFPage firstScanPage;
	PageId firstScanPid;
	
	protected HeapScan(HeapFile hf){
		this.hf = hf;
		this.firstScanPid = hf.firstPid;
		this.firstScanPage = hf.hfpage;
		Minibase.BufferManager.pinPage(firstScanPid, firstScanPage, false);//test1 needs first pin, this passes scan issue
		
	}
	
	protected void finalize() throws Throwable{

	}
	
	public void close()throws ChainException{
		try{
			throw new ChainException(null,"FUCK YOU");
		}catch (ChainException e){
			throw new ChainException(e,"Chain exception in close*)");
			}
	}
	
	public boolean hasNext(){
		return true;
	}
	
	//cant work on insertRecord until getNext is done
	//I think I got most of it but still getting issues when I call make
	//when test1 goes through while loop and it will return null values infinitly, test1 looping starts line 184
	//may be problem with insertRecord or something else
	//https://github.com/Hossam-Mahmoud/MinibaseProject_Wisconsin/blob/master/HeapFile/src/heap/Heapfile.java
	//https://github.com/AhmedGad/Database/blob/master/decompiled/heap/HeapScan.java
	public Tuple getNext(RID rid){
		Tuple tup;
		PageId ridpageno = rid.pageno;//grab pageid from rid
		HFPage tempPage = new HFPage();//new page
		Minibase.BufferManager.pinPage(ridpageno, tempPage, false);//link pageid and tempPage
		Minibase.BufferManager.unpinPage(ridpageno, true);//reset counter
		
		RID newRid = tempPage.nextRecord(rid);//get next Rid
		if(newRid == null){//if rid is at end of page
			PageId tempPid = tempPage.getNextPage();////get next page in file
			if(tempPid == null){//if return was null, given rid was last rid and return null
				return null;
			}else{
				Minibase.BufferManager.pinPage(tempPid, tempPage, false);//next page exist and linking
				Minibase.BufferManager.unpinPage(tempPid, true);//reset counter
				byte[] tupleByte = tempPage.selectRecord(tempPage.firstRecord());//get byte array of record from the next page, will be first record in page
				tup = new Tuple(tupleByte, 0, tupleByte.length);//make it tuple
				return tup;//tup it up
			}
		}else{
			byte[] tupleByte = tempPage.selectRecord(tempPage.firstRecord());//make byte array for tuple
			tup = new Tuple(tupleByte, 0, tupleByte.length);//tuple it all together
			return tup;//return
		}
	}
}
