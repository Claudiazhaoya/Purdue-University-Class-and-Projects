I think I did the java doc correctly please let me know if it is wrong.
