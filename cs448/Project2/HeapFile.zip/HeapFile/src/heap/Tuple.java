package heap;

import java.util.*;
import global.*;
import diskmgr.*;
import java.io.*;

public class Tuple {
	protected byte[] data;
	protected int length;
	
	public Tuple(){
		this.data = null;
	}
	
	public Tuple(byte[] data, int ridIndex, int length){
		for(int i = ridIndex; i < length + ridIndex; i++){
			this.data[i-ridIndex] = data[i];
		}
		this.length = data.length;
	}
	public int getLength(){
		return this.length;
	}
	public byte[] getTupleByteArray(){
		return this.data;
	}
}
