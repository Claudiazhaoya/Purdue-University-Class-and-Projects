
public class NotATeamException extends Exception {
	String s = "Not a Team Please try again";
	public NotATeamException(String team) {
		this.s = team + " is not a team. Please try again";
	}
	public String toString() {
		return s;
	}
}

