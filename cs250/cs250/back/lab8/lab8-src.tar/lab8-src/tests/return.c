
long compute(long a, long b) {
	long x;
	x = a + b;
	return x;
}

void main()
{
	long f;
	f = compute(5, 6);
	printf("sum=%d\n", f);
}

