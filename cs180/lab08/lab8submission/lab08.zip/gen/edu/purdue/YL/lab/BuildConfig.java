/** Automatically generated file. DO NOT MODIFY */
package edu.purdue.YL.lab;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}