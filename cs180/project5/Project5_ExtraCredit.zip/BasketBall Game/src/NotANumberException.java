
public class NotANumberException extends Exception {
	String s = " Is not a number please try again";
	String e = "";
	public NotANumberException(String e) {
		this.e = e + s;
	}
	public String toString() {
		return e;
	}
}
