
void main()
{
	printf("5+3*2=%d\n", 5+3*2);
}

