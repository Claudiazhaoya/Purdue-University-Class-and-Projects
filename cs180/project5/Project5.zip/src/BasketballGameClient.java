import java.util.Scanner;
import javax.swing.JOptionPane;
public class BasketballGameClient extends BasketballGame {
	
	public BasketballGameClient(String team1, String team2, int score1, int score2, boolean status) {
		super(team1, team2, score1, score2, status);
	}
	public void add(String team, String ammount)throws NotATeamException, InvalidScoreException, NotANumberException {
		if ((!team.matches(getTeam1())) && (!team.matches(getTeam2()))) {
			throw new NotATeamException(team);
		}
		if (!ammount.matches("[0-9]")) {
			throw new NotANumberException(ammount);
		}
		int score = Integer.parseInt(ammount);
		if (score != 1 && score != 2 && score != 3) {
			throw new InvalidScoreException(score);
		}
		if (team.matches(getTeam1())) {
			this.setTeam1Score(score);
		}
		else if (team.matches(getTeam2())) {
			this.setTeam2Score(score);
		}
	}
	public void checkInputString(String input)throws NotValidInputException {
		if (!input.contains("-") && !input.matches("END")) {
			throw new NotValidInputException(input);
		}
	}
	public void active() {
		String temp;
		String team;
		String score;
		int ammount;
		int index;
		Scanner input = new Scanner(System.in);
		while (true) {
			System.out.println("Enter team that scored and score: team-score: enter END to finish game");
			temp = input.nextLine();
			try {
				checkInputString(temp);
			} catch (NotValidInputException e) {
				System.out.println(e.e);
				this.active();
			}
			if (temp.matches("END")) {
				setStatus(false);
				break;
			}
			index = temp.indexOf("-");
			team = temp.substring(0, index);
			score = temp.substring(index + 1, temp.length());
			try {
				this.add(team, score);
			} catch (NotATeamException e) {
				System.out.println(e.s);
				this.active();
			} catch (InvalidScoreException e) {
				System.out.println(e.e);
				this.active();
			} catch (NotANumberException e) {
				System.out.println(e.e);
				this.active();
			}
   
			System.out.println(getTeam1() + " score is: " + getTeam1Score());
			System.out.println(getTeam2() + " score is: " + getTeam2Score());
			if (getTeam1Score() > getTeam2Score()) {
				System.out.println("Current Winner is: " + getTeam1());
			} else if (getTeam2Score() > getTeam1Score()) {
				System.out.println("Current Leader is: " + getTeam2());
			} else {
				System.out.println("Currently Tied");
			}
		}
	}
	public static void main(String[] args) {
		String t1;
		String t2;
		Scanner in = new Scanner(System.in);
		do {
			System.out.println("Enter the name of the first team:");
			t1 = in.nextLine();
		} while(t1.matches(""));
  
		do {
			System.out.println("Enter the name of the second team:");
			t2 = in.nextLine();
		} while(t2.matches(""));
		BasketballGameClient game = new BasketballGameClient(t1, t2, 0, 0, true);
		game.active();
		String output = t1 + "score: " + game.getTeam1Score() + "\n" + t2 + "score: " + game.getTeam2Score();
		output = output + "\n\n number of each basket\n 1 point baskets: " + game.getNumBasket(0);
		output = output + "\n 2 point baskets: " + game.getNumBasket(1) + "\n 3 point baskets: " + game.getNumBasket(2);
		JOptionPane.showMessageDialog(null, output, "Game over", JOptionPane.INFORMATION_MESSAGE);
	}
}