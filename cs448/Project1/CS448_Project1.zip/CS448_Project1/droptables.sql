drop table ProjectManager;
drop table EmpProject;
drop table Graduate;
drop table Project;
drop table Employee;
drop table Department;
drop table University;