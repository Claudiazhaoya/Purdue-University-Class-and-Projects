
public class NotValidInputException extends Exception {
	String s = " Is not valid Input please try again";
	String e = "";
	public NotValidInputException(String e) {
		this.e = e + s;
	}
	public String toString() {
		return e;
	}

}
