import java.util.Scanner;
import javax.swing.JOptionPane;
public class BasketballGameClient extends BasketballGame {
	
	public BasketballGameClient(String team1, String team2, int score1, int score2, boolean status) {
		super(team1, team2, score1, score2, status);
	}
	public void add(String team, String ammount)throws NotATeamException, InvalidScoreException, NotANumberException {
		if ((!team.matches(getTeam1())) && (!team.matches(getTeam2()))) {
			throw new NotATeamException(team);
		}
		if (!ammount.matches("[0-9]")) {
			throw new NotANumberException(ammount);
		}
		int score = Integer.parseInt(ammount);
		if (score != 1 && score != 2 && score != 3) {
			throw new InvalidScoreException(score);
		}
		if (team.matches(getTeam1())) {
			this.setTeam1Score(score);
		}
		else if (team.matches(getTeam2())) {
			this.setTeam2Score(score);
		}
	}
	public void checkTeam(String input)throws  NotATeamException {
		if ((!input.matches(getTeam1())) && (!input.matches(getTeam2()))&&(!input.matches("END"))) {
			throw new NotATeamException(input);
		}
	}
	public void active() {
		String temp;
		String team;
		String score;
		int ammount;
		int index;
		Scanner input = new Scanner(System.in);
		while (true) {
			String[] Ammounts = {"1","2","3"};
			temp = JOptionPane.showInputDialog(null,"Please enter the name of the team that scored or END to finish:" ,"SCORE! ",JOptionPane.QUESTION_MESSAGE);
			try{
				this.checkTeam(temp);
				if (temp.matches("END")) {
					setStatus(false);
					break;
				}
			} catch (NotATeamException e) {
				JOptionPane.showMessageDialog(null, e.s,"Not A Team",JOptionPane.WARNING_MESSAGE);
				this.active();
			}
			
			score = (String) JOptionPane.showInputDialog(null,"Select the ammount scored from the drop down menu","Select score",JOptionPane.QUESTION_MESSAGE,null,Ammounts,Ammounts[0]);

			team = temp;
			try {
				this.add(team, score);
			} catch (NotATeamException e) {
				System.out.println(e.s);
				this.active();
			} catch (InvalidScoreException e) {
				System.out.println(e.e);
				this.active();
			} catch (NotANumberException e) {
				System.out.println(e.e);
				this.active();
			}
			String CurrentOut = getTeam1() + " score is: " + getTeam1Score();
			CurrentOut+="\n"+ getTeam2() + " score is: " + getTeam2Score();
			if (getTeam1Score() > getTeam2Score()) {
				CurrentOut+="\n"+"Current Winner is: " + getTeam1();
			} else if (getTeam2Score() > getTeam1Score()) {
				CurrentOut+="\n"+"Current Leader is: " + getTeam2();
			} else {
				CurrentOut+="\n"+"Currently Tied";
			}
			String status ="";
			if(getStatus()==true){
				status = "playing";
			}else{
				status = "game over";
			}
			JOptionPane.showMessageDialog(null, CurrentOut, "Current Status: "+status, JOptionPane.INFORMATION_MESSAGE);
		}
	}
	public static void main(String[] args) {
		String t1;
		String t2;
		Scanner in = new Scanner(System.in);
		do {
			//System.out.println("Enter the name of the first team:");
			//t1 = in.nextLine();
			t1 = JOptionPane.showInputDialog(null,"Please enter the name of the first team: ","Team 1",JOptionPane.QUESTION_MESSAGE);
		} while(t1.matches(""));
  
		do {
			//System.out.println("Enter the name of the second team:");
			//t2 = in.nextLine();
			t2 = JOptionPane.showInputDialog(null,"Please enter the name of the second team: ","Team 2",JOptionPane.QUESTION_MESSAGE);
		} while(t2.matches(""));
		BasketballGameClient game = new BasketballGameClient(t1, t2, 0, 0, true);
		game.active();
		String output = t1 + " score: " + game.getTeam1Score() + "\n" + t2 + " score: " + game.getTeam2Score();
		output = output + "\n\n number of each basket\n 1 point baskets: " + game.getNumBasket(0);
		output = output + "\n 2 point baskets: " + game.getNumBasket(1) + "\n 3 point baskets: " + game.getNumBasket(2);
		JOptionPane.showMessageDialog(null, output, "Game over", JOptionPane.INFORMATION_MESSAGE);
	}
}