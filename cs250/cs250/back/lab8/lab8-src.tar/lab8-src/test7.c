
long compute(long a, long b, long r) {
	return 12;
}

void main()
{
	printf("compute(3,4,5)=%d\n", compute(3,4,5)); 
}

