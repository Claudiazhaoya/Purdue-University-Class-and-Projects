
void main()
{
	if (1) {
		printf("OK1\n");
	}

	if (0) {
		printf("OK2\n");
	}

	if (1) {
		printf("OK3\n");
	}
	else {
		printf("OK4\n");
	}

	if (0) {
		printf("OK5\n");
	}
	else {
		printf("OK6\n");
	}

	printf("OK7\n");
}
