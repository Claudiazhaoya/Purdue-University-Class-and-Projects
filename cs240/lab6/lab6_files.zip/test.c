/*******************************************************************************
 *  test.c
 *
 *  Created on: Feb 24, 2013
 *  CS240 lab6, Spring  2013
 *
 *  Main source file to parse the arguments and call the encryption function 
/********************************************************************************/

#include "cipher.h"

/* number of bytes read from the input */
int bytesRead;

extern char* encryptNames[ENC_IMPLS];
extern encryptFunc encrypts[ENC_IMPLS];

/*
 * main implementation function
 */
int main(int argc, char *argv[]) { 
  //define input/output arrays

  //process command lines

  /* FILL THIS IN */
  abort (); //DELETE THIS LINE
  
}

